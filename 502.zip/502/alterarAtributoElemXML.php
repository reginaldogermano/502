<?php

$apostilas = new SimpleXMLElement('apostilas.xml', null, true );

echo "<pre>";
$apostilas->book[0]->attributes()->id = "bk1001";

$apostilas->saveXML('apostilas.xml');
