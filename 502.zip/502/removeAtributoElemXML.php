<?php

$apostilas = new SimpleXMLElement('apostilas.xml', null, true );

echo "<pre>";


unset( $apostilas->book[0]->attributes()->germano );



$apostilas->saveXML('apostilas.xml');
