<?php

echo date("d/m/Y", strtotime("+1 day"));
echo "<hr>";

echo mktime(22,24,0,3,27,2018);