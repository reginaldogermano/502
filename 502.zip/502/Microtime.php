<?php

echo microtime();