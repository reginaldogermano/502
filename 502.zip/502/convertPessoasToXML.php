<?php 

$pessoas = [
	[
		'nome' => 'Heath Ledger',
		'data_nasc' => '19/05/1956',
	],
	[
		'nome' => 'Alfie Allen',
		'data_nasc' => '10/07/1993',
	],
	[
		'nome' => 'Taylor Kinney',
		'data_nasc' => '04/09/1979',
	],
	[
		'nome' => 'Audrey Hepburn',
		'data_nasc' => '13/07/1972',
	],
];


/*
function test_print($item, $key)
{
    echo "$key holds $item\n";
}
*/


//array_walk_recursive( $pessoas, array($apostilas , 'addChild') );
//echo "<pre>";
///print $apostilas->asXML();


$apostilas = new SimpleXMLElement( '<?xml version="1.0" encoding="UTF-8"?><pessoas></pessoas>');

foreach ($pessoas as $listpessoas){

	$pessoa = $apostilas->addChild('pessoa');
	$pessoa->addChild('nome', $listpessoas['nome']);
	$pessoa->addChild('data_nasc', $listpessoas['data_nasc']);

}

$apostilas->saveXML('pessoas.xml');

