<?php

$apostilas = new SimpleXMLElement('apostilas.xml', null, true );

//$apostilas->book[0]->author = "Reginaldo Germano";
$apostilas->book[0]->addChild("Germano",100);
$apostilas->book[1]->addChild("Germano",101);
$apostilas->book[2]->addChild("Germano",102);

$apostilas->saveXML('apostilas.xml');

//header('Content-type: text/xml');

//echo $apostilas->asXML();