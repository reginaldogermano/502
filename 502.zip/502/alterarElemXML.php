<?php

$apostilas = new SimpleXMLElement('apostilas.xml', null, true );

$apostilas->book[0]->author = "Reginaldo Germano";

$apostilas->saveXML('apostilas.xml');

//header('Content-type: text/xml');

//echo $apostilas->asXML();