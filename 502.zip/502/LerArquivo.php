<?php 

echo "<hr/>";

$filename = "arquivo.txt";

$arquivo = file_get_contents($filename);

echo nl2br( $arquivo );


echo "<hr/>";

$File = fopen($filename, 'r');

while( ( $pedaco = fread ($File, 5)) != false ){

	echo nl2br( $pedaco );

}


fclose($File );
