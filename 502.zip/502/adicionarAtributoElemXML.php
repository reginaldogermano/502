<?php

$apostilas = new SimpleXMLElement('apostilas.xml', null, true );

echo "<pre>";

$apostilas->book[0]->attributes()->addAttribute('germano','bk2001');

$apostilas->saveXML('apostilas.xml');
