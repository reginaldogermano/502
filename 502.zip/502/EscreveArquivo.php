<?php 

echo "<hr/>";

$filename = "arquivo.txt";

$arquivo = fopen($filename , 'a' );

fwrite ($arquivo, "Ola Germano" . PHP_EOL);


/*
while( ( $pedaco = fread ($File, 5)) != false ){

	echo nl2br( $pedaco );

}
*/

file_put_contents($filename, "oi oi" . PHP_EOL, FILE_APPEND);


fclose( $arquivo  );
