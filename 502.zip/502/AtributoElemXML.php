<?php

$apostilas = new SimpleXMLElement('apostilas.xml', null, true );



echo "<pre>";
print_r( $apostilas->book[0]->attributes() );
