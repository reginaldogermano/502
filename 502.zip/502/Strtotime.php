<?php


echo strtotime("now");
echo "<hr>";

echo strtotime("27 March 2018");
echo "<hr>";

echo strtotime("+1 day");
echo "<hr>";

echo strtotime("+1 week");
echo "<hr>";


echo strtotime("+1 week 2 days");
echo "<hr>";

echo strtotime("next Turday");
echo "<hr>";

echo strtotime("last Monday");
echo "<hr>";