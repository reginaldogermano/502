<?php


echo date('d/m/Y');

echo "<hr>";

echo date('D/M/Y');

echo "<hr>";

echo date('d/m/Y H:i:s');

echo "<hr>";