<?php

// Alterando perfil

$filename = "arquivo.txt";

chmod($filename, 0777);

//chown($filename, 'developer');

$status = stat($filename);

echo "<pre>";
print_r( $status );

touch('germano.txt');

var_dump( file_exists("germano.txt") );
var_dump( file_exists("germano2.txt") );

mkdir('fotos');

