<?php

$apostilas = new SimpleXMLElement('apostilas.xml', null, true );


foreach ($apostilas as $apostila ) {
	unset($apostila->Germano );
}

//unset($apostilas->book[1]->Germano );


$apostilas->saveXML('apostilas.xml');

//header('Content-type: text/xml');

//echo $apostilas->asXML();