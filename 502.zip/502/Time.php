<?php

echo time();